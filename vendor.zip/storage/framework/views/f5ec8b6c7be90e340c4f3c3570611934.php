<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.bookingPayment.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.booking-payments.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="amount"><?php echo e(trans('cruds.bookingPayment.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="number" name="amount" id="amount" value="<?php echo e(old('amount', '')); ?>" step="0.01" required>
                <?php if($errors->has('amount')): ?>
                    <span class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bookingPayment.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.bookingPayment.fields.amount_type')); ?></label>
                <select class="form-control <?php echo e($errors->has('amount_type') ? 'is-invalid' : ''); ?>" name="amount_type" id="amount_type">
                    <option value disabled <?php echo e(old('amount_type', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\BookingPayment::AMOUNT_TYPE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('amount_type', 'electricity') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('amount_type')): ?>
                    <span class="text-danger"><?php echo e($errors->first('amount_type')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bookingPayment.fields.amount_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="booking_id"><?php echo e(trans('cruds.bookingPayment.fields.booking')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('booking') ? 'is-invalid' : ''); ?>" name="booking_id" id="booking_id">
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('booking_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('booking')): ?>
                    <span class="text-danger"><?php echo e($errors->first('booking')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.bookingPayment.fields.booking_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shadi-mahal1\resources\views/admin/bookingPayments/create.blade.php ENDPATH**/ ?>