<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.booingDateTime.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.booing-date-times.update", [$booingDateTime->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="booked_date"><?php echo e(trans('cruds.booingDateTime.fields.booked_date')); ?></label>
                <input class="form-control date <?php echo e($errors->has('booked_date') ? 'is-invalid' : ''); ?>" type="text" name="booked_date" id="booked_date" value="<?php echo e(old('booked_date', $booingDateTime->booked_date)); ?>">
                <?php if($errors->has('booked_date')): ?>
                    <span class="text-danger"><?php echo e($errors->first('booked_date')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booingDateTime.fields.booked_date_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="time_slot"><?php echo e(trans('cruds.booingDateTime.fields.time_slot')); ?></label>
                <input class="form-control <?php echo e($errors->has('time_slot') ? 'is-invalid' : ''); ?>" type="text" name="time_slot" id="time_slot" value="<?php echo e(old('time_slot', $booingDateTime->time_slot)); ?>">
                <?php if($errors->has('time_slot')): ?>
                    <span class="text-danger"><?php echo e($errors->first('time_slot')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booingDateTime.fields.time_slot_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shadi-mahal1\resources\views/admin/booingDateTimes/edit.blade.php ENDPATH**/ ?>