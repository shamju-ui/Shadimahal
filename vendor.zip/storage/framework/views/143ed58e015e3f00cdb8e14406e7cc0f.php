<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li>
                    <select class="searchable-field form-control">

                    </select>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs("admin.home") ? "active" : ""); ?>" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('hole_booking_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.hall-bookings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/hall-bookings") || request()->is("admin/hall-bookings/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-book">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.holeBooking.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('new_booking_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.new-bookings.index")); ?>" class="nav-link <?php echo e(request()->is("admin/new-bookings") || request()->is("admin/new-bookings/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-book">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.newBooking.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                <i class="fa-fw fas fa-key nav-icon">
                                </i>
                                <p>
                                    <?php echo e(trans('global.change_password')); ?>

                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt nav-icon">

                            </i>
                            <p><?php echo e(trans('global.logout')); ?></p>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\wamp64\www\shadi-mahal1\resources\views/partials/menu.blade.php ENDPATH**/ ?>