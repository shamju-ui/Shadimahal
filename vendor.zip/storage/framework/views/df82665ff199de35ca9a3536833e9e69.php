<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Report
    </div>

    <div class="card-body">
        <form id="reportForm">
            <div class="form-group">
                <div class="row">
                    <div class="col-4">
                        <label for="year">Select Year</label>
                        <select name="year" id="year" class="form-control">
                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4" style="align-content: end;">
                        <label for="year"></label>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </form>

        <div id="reportContent">
            <!-- Report data will be inserted here -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#reportForm').on('submit', function(e) {
            e.preventDefault();
            var year = $('#year').val();
            $.ajax({
                url: '<?php echo e(route('admin.reports.data')); ?>',
                type: 'GET',
                data: { year: year },
                success: function(response) {
                    $('#reportContent').html(`
                        <div class="row">
                            <div class="col-6">
                                <h3>Current Year (${year})</h3>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Booking Data</th>
                                            <th>Count</th>
                                            <th>Total Amount</th>
                                            <th>Total Discount</th>
                                            <th>Amount Received</th>
                                            <th>Outstanding</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Total Bookings</td>
                                            <td>${response.totalCount}</td>
                                            <td>${response.totalAmount.toFixed(2)}</td>
                                            <td>${response.totalDiscount.toFixed(2)}</td>
                                            <td>${response.totalReceived.toFixed(2)}</td>
                                            <td>${response.totalOutstanding.toFixed(2)-response.totalDiscount.toFixed(2)}</td>
                                        </tr>
                                        <tr>
                                            <td>AM</td>
                                            <td>${response.amCount}</td>
                                            <td>${response.amTotal.toFixed(2)}</td>
                                            <td>${response.amDiscount}</td>
                                            <td>${response.amReceived.toFixed(2)}</td>
                                            <td>${(response.amTotal - response.amReceived-response.amDiscount).toFixed(2)}</td>
                                        </tr>
                                        <tr>
                                            <td>PM</td>
                                            <td>${response.pmCount}</td>
                                            <td>${response.pmTotal.toFixed(2)}</td>
                                            <td>${response.pmDiscount}</td>
                                            <td>${response.pmReceived.toFixed(2)}</td>
                                            <td>${(response.pmTotal - response.pmReceived-response.pmDiscount).toFixed(2)}</td>
                                        </tr>
                                      
                                        <tr>
                                            <td>Canceled</td>
                                            <td>${response.canceledCount}</td>
                                            <td>N/A</td>
                                            <td>N/A</td>
                                            <td>${response.canceledAmount}</td>
                                        </tr> 
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-6">
                                <h3>Booking By Month (${year})</h3>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Count</th>
                                            <th>Total Amount</th>
                                            <th>Received</th>
                                            <th>Outstanding</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${response.bookingsByMonth.map(month => `
                                            <tr>
                                                <td>${new Date(0, month.month - 1).toLocaleString('default', { month: 'long' })}</td>
                                                <td>${month.count}</td>
                                                <td>${response.bookingsByMonthAmount[month.month]?.total_amount.toFixed(2) || 0}</td>
                                                <td>${response.bookingsByMonthReceived[month.month]?.total_amount.toFixed(2) || 0}</td>
                                                <td>${(response.bookingsByMonthAmount[month.month]?.total_amount || 0 - (response.bookingsByMonthReceived[month.month]?.total_amount || 0)).toFixed(2)}</td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `);
                }
            });
        });

        // Trigger the initial load
        $('#reportForm').submit();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shadi-mahal1\resources\views/home.blade.php ENDPATH**/ ?>