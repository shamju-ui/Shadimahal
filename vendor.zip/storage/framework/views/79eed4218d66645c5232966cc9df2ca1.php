<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.holeBooking.title_singular')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.hall-bookings.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
                
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th style="width: 200px;"><?php echo e(trans('cruds.holeBooking.fields.name')); ?></th>
                        <td><?php echo e($holeBooking->name); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.mobile_1')); ?></th>
                        <td><?php echo e($holeBooking->mobile_1); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.mobile_2')); ?></th>
                        <td><?php echo e($holeBooking->mobile_2); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.address_line_1')); ?></th>
                        <td><?php echo e($holeBooking->address_line_1); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.address_line_2')); ?></th>
                        <td><?php echo e($holeBooking->address_line_2); ?></td>
                    </tr>
                    <tr>
                        <th>Event type</th>
                        <td><?php echo e($holeBooking->event_type); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.total_amount')); ?></th>
                        <td><?php echo e($holeBooking->total_amount); ?></td>
                    </tr>
                    <tr>
                        <th>Discount</th>
                        <td><?php echo e($holeBooking->discount); ?></td>
                    </tr>
                    <tr>
                        <th>Discount By</th>
                        <td><?php echo e($holeBooking->discount_by); ?></td>
                    </tr>
                    <tr>
                        <th>Advance Paid</th>
                        <td><?php echo e($bookingPayments->first()->amount ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Adavnce receipt</th>
                        <td><?php echo e($bookingPayments->first()->receipt ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Advance Entry Date</th>
                        <td><?php echo e($bookingPayments->first()->date_1 ?? ''); ?></td>
                    </tr>
                    <?php if($bookingPayments->count() > 1): ?>
                    <tr>
                        <th>Balance Amount</th>
                        <td><?php echo e($bookingPayments->get(1)->amount ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Balace receipt</th>
                        <td><?php echo e($bookingPayments->get(1)->receipt ?? ''); ?></td>
                    </tr>
                    <tr>
                        <th>Balance Entry Date</th>
                        <td><?php echo e($bookingPayments->get(1)->date_2 ?? ''); ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th><?php echo e(trans('cruds.holeBooking.fields.comment')); ?></th>
                        <td><?php echo e($holeBooking->comment); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\shadi-mahal1\resources\views/admin/hallBookings/show.blade.php ENDPATH**/ ?>