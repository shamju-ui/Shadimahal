<?php

return [
    'site_title' => 'Shadimahal',

];
